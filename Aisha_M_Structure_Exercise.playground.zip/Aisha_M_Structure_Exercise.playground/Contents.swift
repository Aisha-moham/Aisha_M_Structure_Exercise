import Cocoa

var str = "Hello, playground"

struct EngineStruct {
    var v8: Int
    var car:String
    var version: Int
}

var Engine1 = EngineStruct(v8:8, car:"Dodge", version: 3)

print("The versions of engine is \(Engine1.version)")
print("The type of car that has a  v8 \(Engine1.car)")
print("The engine is \(Engine1.v8)")
